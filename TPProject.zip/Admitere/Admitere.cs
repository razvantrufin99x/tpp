using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Admitere
{
	public class Admitere
	{
		Lista ListaCandidati;
		Lista ListaOrdonata;
		bool TrecutNote;

		public void Init()
		{
			throw new NotImplementedException();
		}

		public void AfisareMeniu()
		{
			throw new NotImplementedException();
		}

		public void SelectieValidareComanda()
		{
			throw new NotImplementedException();
		}

		public void Prezent()
		{
			throw new NotImplementedException();
		}

		public void ProcInscriere()
		{
			throw new NotImplementedException();
		}

		public void ProcModificare()
		{
			throw new NotImplementedException();
		}

		public void ProcRetragere()
		{
			throw new NotImplementedException();
		}

		public void ProcNote()
		{
			throw new NotImplementedException();
		}

		public void ProcOrdonare()
		{
			throw new NotImplementedException();
		}

		public void ProcAfisare()
		{
			throw new NotImplementedException();
		}

		public void Main()
		{
			throw new NotImplementedException();
		}
	}
}
