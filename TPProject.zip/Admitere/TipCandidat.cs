using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Admitere
{
	public class TipCandidat
	{
		SIR nume;
		SIR numar;
		Lista <int > note;
		float medie;
	}
}
