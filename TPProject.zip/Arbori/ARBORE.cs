using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Arbori
{
	public class ARBORE
	{
		Element AdrInfo;
		int DECALAJ;
		int LGINF;
		int MAXNIVELE;
		int K;
		int CH;
		int [] STANGA;
		int [] DRAPTA;
		int [] VERTICAL;
		int[,] ANTET;

		public void Main()
		{
			throw new NotImplementedException();
		}

		public void ANITIALIZEAZAARBORE()
		{
			throw new NotImplementedException();
		}

		public void TESTARBOREVID()
		{
			throw new NotImplementedException();
		}

		public void CONSTRUIESTEARBORE()
		{
			throw new NotImplementedException();
		}

		public void DISTRUGERADACINA()
		{
			throw new NotImplementedException();
		}

		public void MODIFICAINFORMATIE()
		{
			throw new NotImplementedException();
		}

		public void MODIFICASTANGA()
		{
			throw new NotImplementedException();
		}

		public void MODIFICADREAPTA()
		{
			throw new NotImplementedException();
		}

		public void ADRESAINFORMATIE()
		{
			throw new NotImplementedException();
		}

		public void SUBARBORESTANG()
		{
			throw new NotImplementedException();
		}

		public void SUBARBOREDREPT()
		{
			throw new NotImplementedException();
		}

		public void FRUNZA()
		{
			throw new NotImplementedException();
		}

		public void NUMARNODURI()
		{
			throw new NotImplementedException();
		}

		public void INALTIME()
		{
			throw new NotImplementedException();
		}

		public void CAUTASUBARBORE()
		{
			throw new NotImplementedException();
		}

		public void DISTRUGEARBORE()
		{
			throw new NotImplementedException();
		}

		public void DISTRUGEINFORMATIE()
		{
			throw new NotImplementedException();
		}

		public void PARCURGEINPOSTORDINE()
		{
			throw new NotImplementedException();
		}

		public void PARCURGEINPREORDINE()
		{
			throw new NotImplementedException();
		}

		public void PARCURGEININORDINE()
		{
			throw new NotImplementedException();
		}

		public void PARCURGEINADINCIME()
		{
			throw new NotImplementedException();
		}

		public void PARCURGEINLATIME()
		{
			throw new NotImplementedException();
		}

		public void DISTRA()
		{
			throw new NotImplementedException();
		}

		public void ADAUGAFRUNZA()
		{
			throw new NotImplementedException();
		}

		public void CONSTRUIESTEARBOREBINAR()
		{
			throw new NotImplementedException();
		}

		public void RASPUNS()
		{
			throw new NotImplementedException();
		}

		public void TPREORDINE()
		{
			throw new NotImplementedException();
		}

		public void TIPARIREINPREORDINE()
		{
			throw new NotImplementedException();
		}

		public void TIPARIRELG()
		{
			throw new NotImplementedException();
		}

		public void TINORDINE()
		{
			throw new NotImplementedException();
		}

		public void TIPARIREININORDINE()
		{
			throw new NotImplementedException();
		}

		public void EGAL()
		{
			throw new NotImplementedException();
		}

		public void TESTCAUTARE()
		{
			throw new NotImplementedException();
		}

		public void TIPARIRE()
		{
			throw new NotImplementedException();
		}

		public void TIPARIRECUPARANTEZECOMPLETE()
		{
			throw new NotImplementedException();
		}
	}
}
