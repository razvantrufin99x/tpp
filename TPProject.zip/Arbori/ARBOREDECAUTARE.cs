using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Arbori
{
	public class ARBOREDECAUTARE
	{
		public void INSERARENOD()
		{
			throw new NotImplementedException();
		}

		public void ELIMINANOD()
		{
			throw new NotImplementedException();
		}

		public void CAUTANOD()
		{
			throw new NotImplementedException();
		}

		public void CAUTASIELIMINA()
		{
			throw new NotImplementedException();
		}
	}
}
