using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Arbori
{
	public class ARBORESELECTIE
	{
		TABLOUINFO INF;
		int NN;
		RELATIE REL;

		public void INITARBSEL()
		{
			throw new NotImplementedException();
		}

		public void TESTARBSELVID()
		{
			throw new NotImplementedException();
		}

		public void ADAUGAINARBSEL()
		{
			throw new NotImplementedException();
		}

		public void RADACINAARBSEL()
		{
			throw new NotImplementedException();
		}

		public void EXTRAGEDINARBSEL()
		{
			throw new NotImplementedException();
		}

		public void NRNODURIARBSEL()
		{
			throw new NotImplementedException();
		}
	}
}
