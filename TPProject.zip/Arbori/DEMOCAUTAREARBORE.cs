using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Arbori
{
	public class DEMOCAUTAREARBORE
	{
		Element ADRINF;
		ARBORE RAD;

		public void EG()
		{
			throw new NotImplementedException();
		}

		public void MAIMIC()
		{
			throw new NotImplementedException();
		}

		public void RELSUBARBORE()
		{
			throw new NotImplementedException();
		}

		public void CONSTARBORECAUTARE()
		{
			throw new NotImplementedException();
		}
	}
}
