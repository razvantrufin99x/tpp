using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Arbori
{
	public class RELATIE
	{
		public void RELATIE()
		{
			throw new NotImplementedException();
		}
	}
}
