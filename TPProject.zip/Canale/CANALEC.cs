using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Canale
{
	public class CANALEC
	{
		List <CANAL > CANALE;
		int N;
		int NUMAR;

		public void CITIRELISTACANALE()
		{
			throw new NotImplementedException();
		}

		public void AFISAREAMPLASARI()
		{
			throw new NotImplementedException();
		}

		public void CONTRADICTIE()
		{
			throw new NotImplementedException();
		}

		public void AMPLASARECANAL()
		{
			throw new NotImplementedException();
		}

		public void PRIMUL()
		{
			throw new NotImplementedException();
		}

		public void NEFIXAT()
		{
			throw new NotImplementedException();
		}

		public void CONDITIONAT()
		{
			throw new NotImplementedException();
		}

		public void CANALCUNRMAXCONTRAD()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
