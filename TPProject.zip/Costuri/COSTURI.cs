using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Costuri
{
	public class COSTURI
	{
		public void CITESTECOSTURI()
		{
			throw new NotImplementedException();
		}
	}
}
