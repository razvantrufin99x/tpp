using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Culori
{
	public class CULORI
	{
		int NL;
		int NG;
		int NC;
		int NS;
		int[,] A;
		int[] SOLOPT;
		int SMAX;
		SOLUTIE SOL;

		public void VECIN()
		{
			throw new NotImplementedException();
		}

		public void TESTOPTIM()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
