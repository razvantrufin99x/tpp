using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Culori
{
	public class SOLUTIE
	{
		int C;
		int S;
	}
}
