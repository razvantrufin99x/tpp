using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Datorii
{
	public class DATORII
	{
		List <NMAXNODURI> VIZITATE;
		List <NMAXLEGATURI> COST;
		COADA Q;

		public void CALCULDATORII()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
