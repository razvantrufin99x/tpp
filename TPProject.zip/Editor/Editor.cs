using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Editor
{
	public class Editor
	{
		char SFARSIT = 26;
		char CR = '\r';
		bool gata;
		char c;
		POZITIE PozitieCursor;
		StivaDinamica stiva;

		public void CRLF()
		{
			throw new NotImplementedException();
		}

		public void AvansCursor()
		{
			throw new NotImplementedException();
		}

		public void TratareParantezeDeschise()
		{
			throw new NotImplementedException();
		}

		public void TratareParantezeInchise()
		{
			throw new NotImplementedException();
		}

		public void Main()
		{
			throw new NotImplementedException();
		}
	}
}
