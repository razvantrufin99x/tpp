using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.ExplorareGraf
{
	public class COADALARGIME
	{
		public void INITIALIZEAZACOADAI()
		{
			throw new NotImplementedException();
		}

		public void INTRODUCEINCOADAI()
		{
			throw new NotImplementedException();
		}

		public void EXTRAGEDINCOADAI()
		{
			throw new NotImplementedException();
		}

		public void TESTCOADAGOALAI()
		{
			throw new NotImplementedException();
		}
	}
}
