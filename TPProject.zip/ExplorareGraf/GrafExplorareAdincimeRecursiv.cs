using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.ExplorareGraf
{
	public class GrafExplorareAdincimeRecursiv
	{
		List <STIVAADINCIME> STIVA;
		List <NMAXNODURI> VIZITATE;

		public void EXPLORAREADINCIMERECURSIV()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
