using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Grafuri
{
	public class COMUNE
	{
		int MAXNODURI;
		int NMAXLEGATURI;

		public text EROARE()
		{
			throw new NotImplementedException();
		}

		public text EX_EROARE()
		{
			throw new NotImplementedException();
		}
	}
}
