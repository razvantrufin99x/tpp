using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Lista
{
	public class ListaDinamica
	{
		int lungime;
		celula inceput;
		celula curent;
		celula sfarsit;
	}
}
