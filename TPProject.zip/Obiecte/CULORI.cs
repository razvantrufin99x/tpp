using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Obiecte
{
	public enum CULORI
	{
		ALB,
		ALBASTRU,
		GALBEN,
		VERDE,
		VIOLET,
		ROSU,
		MARO,
		GRI,
		INDIGO,
		KAKI,
		LIME,
		NEGRU,
		OPAL,
		PORTOCALIU,
		ROZ
	}
}
