using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Obiecte
{
	public class Persoana
	{
		string nume;
		string prenume;
		DATA datanasterii;
		TIPSEX sexul;
		float inaltime;
		float greutate;
		CULORI culoareaparului;
	}
}
