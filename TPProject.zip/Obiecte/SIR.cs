using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Obiecte
{
	public class SIR
	{
		List <char> sirul;
	}
}
