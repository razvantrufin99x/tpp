using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Obiecte
{
	public enum TIPSEX
	{
		masculin,
		feminin,
		necunoscut,
		indefinit,
		mixt
	}
}
