using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Oferte
{
	public class OFERTE
	{
		int MAXOFERTE;
		int MAXSOL;
		int N;
		int C;
		int [] S;
		int[] F;
		int[] B;
		int[,] SOL_OPT;
		int I;
		int J;
		int NSOL;
		int PROFIT_POTENTIAL;
		int INVESTITIE;
		int PROFIT_OPTIM;
		int INVESTITIE_OPTIMA;

		public void TESTOPTIM()
		{
			throw new NotImplementedException();
		}

		public void EXTINDERE()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
