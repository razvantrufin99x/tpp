using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.PrelucrareGrafuri
{
	public class ARBKRUSK
	{
		Lista <int > COST;
		Lista <int > SELECTATE;
		int[,] T2;
		Lista <int > TATA;
		int COSTMINIM;

		public void INITTATA()
		{
			throw new NotImplementedException();
		}

		public void GASESTECOMPONENTA()
		{
			throw new NotImplementedException();
		}

		public void UNIUNECOMPONENTE()
		{
			throw new NotImplementedException();
		}

		public void GASESTELEGATURAMINIMA()
		{
			throw new NotImplementedException();
		}

		public void ARBOREMINIMKRUSKAL()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
