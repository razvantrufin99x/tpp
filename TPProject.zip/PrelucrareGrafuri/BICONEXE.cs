using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.PrelucrareGrafuri
{
	public class BICONEXE
	{
		Lista <int > VIZITATE;
		Lista <int > APEL;
		Lista <int > MINIM;
		int CONTOR1;
		Lista <int > CLASACURENT;
		Lista <int > TATA;

		public void EXPLORARERECURSIVA3()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
