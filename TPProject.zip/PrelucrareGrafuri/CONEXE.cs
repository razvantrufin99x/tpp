using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.PrelucrareGrafuri
{
	public class CONEXE
	{
		Lista <int > VIZITATE;
		Lista <int > APEL;
		Lista <int > MINIM;
		int CONTOR1;
		Lista <int > CLASACURENT;

		public void EXPLORARERECURSIVA2()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
