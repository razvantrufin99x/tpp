using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.PrelucrareGrafuri
{
	public class DIJKSTRA
	{
		Lista <int > COST;
		Lista <int > SELECTATE;
		Lista <int > DISTANTE;
		Lista <int > TATA;

		public void INITDISTANTE()
		{
			throw new NotImplementedException();
		}

		public void VIRFDISTMINIMA()
		{
			throw new NotImplementedException();
		}

		public void ACTUALIZAREDISTANTE()
		{
			throw new NotImplementedException();
		}

		public void GASESTECAIMINIME()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
