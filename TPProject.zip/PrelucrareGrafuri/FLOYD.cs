using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.PrelucrareGrafuri
{
	public class FLOYD
	{
		Lista <int > COST;
		Lista <int > SELECTATE;
		int[,] A;
		int[,] P;

		public void INITADIP()
		{
			throw new NotImplementedException();
		}

		public void TOATEDISTANTEMINIME()
		{
			throw new NotImplementedException();
		}

		public void CALE()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
