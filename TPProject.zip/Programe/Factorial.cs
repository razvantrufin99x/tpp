using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Programe
{
	public class Factorial
	{
		public int Fact()
		{
			throw new NotImplementedException();
		}
	}
}
