using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Sortare
{
	public class ELEMENTSORT
	{
		int CHEIE;
		SIR TEXT;
	}
}
