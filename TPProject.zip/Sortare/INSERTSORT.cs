using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Sortare
{
	public class INSERTSORT
	{
		int I;
		int J;
		ELEMENTSORT TEMP;

		public INSERTSORT(ELEMENTSORT PX, int N)
		{
			throw new NotImplementedException();
		}
	}
}
