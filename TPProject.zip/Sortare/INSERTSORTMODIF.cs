using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Sortare
{
	public class INSERTSORTMODIF
	{
		int I;
		int J;
		ELEMENTSORT TEMP;
		int INCEPUT;
		int SFARSIT;
		int MIJLOC;

		public INSERTSORTMODIF(ELEMENTSORT PX, int N)
		{
			throw new NotImplementedException();
		}
	}
}
