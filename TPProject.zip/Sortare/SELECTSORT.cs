using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Sortare
{
	public class SELECTSORT
	{
		int J;
		int I;
		int MIN;

		public SELECTSORT(ELEMENTSORT PX, int N)
		{
			throw new NotImplementedException();
		}
	}
}
