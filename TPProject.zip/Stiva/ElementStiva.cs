using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Stiva
{
	public class ElementStiva
	{
		Element valoare;
		Element precedentul;
	}
}
