using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Stiva
{
	public class StivaStatica
	{
		int VirfulStivei;
		List <Element> elemente;

		public void INITIALIZARESTIVA()
		{
			throw new NotImplementedException();
		}

		public void TESTSTIVAGOALA()
		{
			throw new NotImplementedException();
		}

		public void INTRODUCEINSTIVA()
		{
			throw new NotImplementedException();
		}

		public void EXTRAGEDINSTIVA()
		{
			throw new NotImplementedException();
		}

		public void VALOAREDINCAP()
		{
			throw new NotImplementedException();
		}

		public void VALOAREDINCAP()
		{
			throw new NotImplementedException();
		}
	}
}
