using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.TabeleDeDispersie
{
	public class DISPERS
	{
		int DIMENSIUNETABELA;
		char CARACTERDESFARSIT;
		int MAXLISTA;
		SIR VECTOR;
		int URMATORULSIR;
		int CODSIR;
		List < ELEMENTHASH > TABELAHASH;

		public void LISTEAZASIRURI()
		{
			throw new NotImplementedException();
		}

		public void DISPERSIE()
		{
			throw new NotImplementedException();
		}

		public void ONOUAINTRARE()
		{
			throw new NotImplementedException();
		}

		public void CAUTARE()
		{
			throw new NotImplementedException();
		}
	}
}
