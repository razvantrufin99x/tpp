using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.TopologicSort
{
	public class TOPSORT
	{
		int MULTIMEELEMENTE;
		int NEMAX;
		int NRELEMENTE;
		int NRPARTIALSORTATE;
		List <Element> CONDITIONARI;
		Lista <int > LISTASORTATE;

		public void INCLUDE()
		{
			throw new NotImplementedException();
		}

		public void ELIMINA()
		{
			throw new NotImplementedException();
		}

		public void APARTINE()
		{
			throw new NotImplementedException();
		}

		public void TOPSORT()
		{
			throw new NotImplementedException();
		}

		public void CITIRECONDITIONARI()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
