using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Virstnic
{
	public class VIRSTNICRECURSIV
	{
		List <NMAXNODURI> VIZITATE;
		PERSOANA VIRSTNICUL;
		List <PERSOANA> GRUP;

		public void CELMAIVIRSTNIC()
		{
			throw new NotImplementedException();
		}

		public void CITESTEINFONODURI()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}

		public void FVIRSTA()
		{
			throw new NotImplementedException();
		}
	}
}
